package portfolioWR1.portfolioWR1.Controller;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import static org.springframework.data.jpa.domain.AbstractPersistable_.id;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import portfolioWR1.portfolioWR1.Service.IPersonaService;
import portfolioWR1.portfolioWR1.model.Persona;


@RestController
@CrossOrigin(origins = "http://localhost:4200")

public class Controller {
    
 @Autowired
 private IPersonaService persoServ;
 //List<Persona> listaPersona = new ArrayList();   
    
 @GetMapping  ("/hola")
  public String decirHola(){
  return "Hola Mundo";
  }   
  
  @GetMapping  ("/holas/{nombre}")
  public String decirHola(@PathVariable String nombre){
  return "Hola Mundo "+nombre;
  }   
  
  @GetMapping ("/holaa")
  public String decirHolas (@RequestParam String nombre,
                             @RequestParam int edad,
                             @RequestParam String profesion)
  {
      return "Hello Word. " + nombre + " Tu edad es "+edad+ " Tu profesion es "+
              profesion;}
  
    @PostMapping ("/new/persona")
      public void agregarPersona(@RequestBody Persona pers){
        persoServ.crearPersona(pers);
    }  

      
      @GetMapping ("/leer")
      @ResponseBody
      public List <Persona> leerPersona(){
        return persoServ.verPersonas();
      }

  //https://www.youtube.com/watch?v=QQ72JXUQRNE//
     
      @GetMapping ("/buscar/{id}")   //127.0.0.1:8080/buscar/3
      public Persona buscarPersona(@PathVariable Long id){
      return persoServ.buscarPersona(id);
      }
     
      
      @DeleteMapping ("/delete/{id}")
      public void borrarPersona (@PathVariable Long id){
      persoServ.borrarPersona(id);
      }
      
      

   
 
  @PutMapping("/editar/{id}")
   public Persona update(@RequestBody Persona persona, @PathVariable Long id){
          Persona PersonaActual = persoServ.buscarPersona(id);
           PersonaActual.setAcerca1(persona.getAcerca1());
           PersonaActual.setAcerca2(persona.getAcerca2());
           PersonaActual.setAcerca3(persona.getAcerca3());
           PersonaActual.setAcerca4(persona.getAcerca4());
           
           
           PersonaActual.setExperiencia1(persona.getExperiencia1());
           PersonaActual.setExperiencia2(persona.getExperiencia2());
           PersonaActual.setExperienciaImg1(persona.getExperienciaImg1());
           PersonaActual.setExperienciaImg2(persona.getExperienciaImg2());
           
           
           
           PersonaActual.setEducacion1(persona.getEducacion1());
           PersonaActual.setEducacion2(persona.getEducacion2());
           PersonaActual.setEducacionImg1(persona.getEducacionImg1());
           PersonaActual.setEducacionImg2(persona.getEducacionImg2());
           
           
           
           PersonaActual.setHardsoftHtml(persona.getHardsoftHtml());
            PersonaActual.setHardsoftCss(persona.getHardsoftCss());
             PersonaActual.setHardsoftJs(persona.getHardsoftJs());
              PersonaActual.setHardsoftBs(persona.getHardsoftBs());
               PersonaActual.setHardsoftJava(persona.getHardsoftJava());
                PersonaActual.setHardsoftMysql(persona.getHardsoftMysql());
                 PersonaActual.setHardsoftAng(persona.getHardsoftAng());
           
     
           PersonaActual.setProyecto1(persona.getProyecto1());
           PersonaActual.setProyecto2(persona.getProyecto2());
           PersonaActual.setProyectoImg1(persona.getProyectoImg1());
           PersonaActual.setProyectoImg2(persona.getProyectoImg2());
           
           
        persoServ.modificarPersona(PersonaActual);
           return null;
           
           

}
         
                                         
      
      

}
