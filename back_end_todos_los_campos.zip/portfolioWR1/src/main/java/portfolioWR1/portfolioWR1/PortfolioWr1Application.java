package portfolioWR1.portfolioWR1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortfolioWr1Application {

	public static void main(String[] args) {
		SpringApplication.run(PortfolioWr1Application.class, args);
	}

}
