package portfolioWR1.portfolioWR1.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
@Entity
public class Persona {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String acerca1;
    private String acerca2;
    private String acerca3;
    private String acerca4;
    
    private String experiencia1;
    private String experiencia2;
    private String experienciaImg1;
    private String experienciaImg2;
    
    
    private String educacion1;
    private String educacion2;
    private String educacionImg1;
    private String educacionImg2;
    
    
    private String hardsoftHtml;
    private String hardsoftCss;
    private String hardsoftJs;
    private String hardsoftBs;
    private String hardsoftJava;
    private String hardsoftMysql;
    private String hardsoftAng;
         
    
    private String proyecto1;
     private String proyecto2;
     private String proyectoImg1;
     private String proyectoImg2;
    

    
    

    public Persona() {
    }
   

public Persona(Long id, String acerca1, String acerca2, String acerca3, String acerca4,
        String experiencia1, String experiencia2, String experienciaImg1, String experienciaImg2, 
    String educacion1, String educacion2, String educacionImg1, String educacionImg2,  
    String hardsoftHtml,
    String hardsoftCss,
    String hardsoftJs,
    String hardsoftBs,
    String hardsoftJava,
    String hardsoftMysql,
    String hardsoftAng,
    String proyecto1,
    String proyecto2,
    String proyectoImg1,
    String proyectoImg2
          ){
  
    
  this.id = id;
  this.acerca1 = acerca1;
  this.acerca2 = acerca2;
  this.acerca3 = acerca3;
  this.acerca4 = acerca4;
  
  this.experiencia1 = experiencia1;
  this.experiencia2 = experiencia2;
  this.experienciaImg1 = experienciaImg1;
  this.experienciaImg2 = experienciaImg2;
  
  this.educacion1=educacion1;
  this.educacion2=educacion2;
  this.educacion1=educacionImg1;
  this.educacion2=educacionImg2;
  
  
    this.hardsoftHtml=hardsoftHtml;
    this.hardsoftCss=hardsoftCss;
    this.hardsoftJs=hardsoftJs;
    this.hardsoftBs=hardsoftBs;
    this.hardsoftJava=hardsoftJava;
    this.hardsoftMysql=hardsoftMysql;
    this.hardsoftAng=hardsoftAng;     
          
   this.proyecto1=proyecto1;
   this.proyecto2=proyecto2;
   this.educacionImg1=proyectoImg1;
   this.proyectoImg2=proyectoImg2;

  
  
  
}
}
