package portfolioWR1.portfolioWR1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortfolioWr1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
